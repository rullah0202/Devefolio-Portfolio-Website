<!-- This template for displaying -->

  <!-- ---------Header Part--------- -->
  <?php
      get_header();
  ?>

  <!-- ======= Hero Section ======= -->
  <?php get_template_part('template_part/hero'); ?>
  <!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <?php get_template_part('template_part/about'); ?>
    <!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <?php get_template_part('template_part/services'); ?>
    <!-- End Services Section -->

    <!-- ======= Counter Section ======= -->
    <?php get_template_part('template_part/counter'); ?>
    <!-- End Counter Section -->

    <!-- ======= Portfolio Section ======= -->
    <?php get_template_part('template_part/portfolio'); ?>
    <!-- End Portfolio Section -->

    <!-- ======= Testimonials Section ======= -->
    <?php get_template_part('template_part/testimonials'); ?>
    <!-- End Testimonials Section -->

    <!-- ======= Blog Section ======= -->
    <?php get_template_part('template_part/blog'); ?>
    <!-- End Blog Section -->

    <!-- ======= Contact Section ======= -->
    <?php get_template_part('template_part/contact'); ?>
    <!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
    <?php get_footer(); ?>