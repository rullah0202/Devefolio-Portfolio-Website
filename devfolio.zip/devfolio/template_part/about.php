<section id="about" class="about-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="box-shadow-full">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                      <!-- Query for thubmnail, name,profile,email, phone -->
                      <?php get_template_part('template_part/about/about-part','profile'); ?>
                      <!-- End Query for thubmnail, name,profile,email, phone -->

                  </div>
                  <div class="skill-mf">
                    <!-- Query for skill  -->
                    <?php get_template_part('template_part/about/about-part','skill'); ?> 
                  <!--End Query for skill  -->
                  </div>
                </div>
                <div class="col-md-6">
                  <!-- Query for about detail -->
                  <?php get_template_part('template_part/about/about-part','des'); ?>
                       <!-- End Query for about details -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>