<?php
 $wpabout=array('post_type'      => 'about',
  'posts_per_page' => 1,
 'post_status'    => 'publish'
 );
 $aboutquery = new WP_Query($wpabout);
 if($aboutquery->have_posts()) : 

?>
<?php 
 global $post;
  while($aboutquery->have_posts()) : $aboutquery->the_post(); ?>
  <div class="about-me pt-4 pt-md-0">
<div class="title-box-2">
 <h5 class="title-left">
 <?php the_title(); ?>
</h5>
</div>
<?php the_content(); ?>
</div>
<?php endwhile;
 else :
 _e('No post found');
endif; 
?>