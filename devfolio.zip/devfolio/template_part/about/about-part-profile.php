<?php
$wpabout = array(
    'post_type' => 'about',
    'posts_per_page' => 1,
    'post_status' => 'publish'
);
$aboutquery = new WP_Query($wpabout);
if ($aboutquery->have_posts()):

?>
	<?php
    global $post;
    while ($aboutquery->have_posts()):
        $aboutquery->the_post(); ?>
		<div class="col-sm-6 col-md-5">
			<div class="about-img">
				<?php echo the_post_thumbnail('full', array(
            'class' => 'img-fluid rounded b-shadow-a'
        )); ?>
			</div>
		</div>
		<div class="col-sm-6 col-md-7">
			<?php
        $custom_field_keys = get_post_custom_keys();
        foreach ($custom_field_keys as $key => $value)
        {
            $valuet = trim($value);
            if ('_' == $valuet[0]) continue;
            $data = get_post_meta($post->ID, "$value", true)
?>
				<div class="about-info">
					<p><span class="title-s"><?php echo $value; ?>: </span> <span><?php echo $data; ?></span></p>
				</div>
				<?php
        } ?>
		</div>
		<?php
    endwhile;
else:
    _e('No post found');
endif;
?>