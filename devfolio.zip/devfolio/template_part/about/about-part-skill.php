<?php
$wpskill = array(
    'post_type' => 'skill',
    'posts_per_page' => 1,
    'post_status' => 'publish'
);
$skillquery = new WP_Query($wpskill);
if ($skillquery->have_posts()):
?>

                        <?php
    global $post;
    while ($skillquery->have_posts()):
        $skillquery->the_post(); ?>
                        <p class="title-s"><?php the_title(); ?></p>

                        <?php
        $custom_field_keys = get_post_custom_keys();
        foreach ($custom_field_keys as $key => $value)
        {
            $valuet = trim($value);
            if ('_' == $valuet[0]) continue;
            $data = get_post_meta($post->ID, "$value", true)
?>
                        <span><?php echo $value; ?></span> <span class="pull-right"><?php echo $data; ?>%</span>
                        <div class="progress">
                          <div class="progress-bar" role="progressbar" style="width: <?php echo $data; ?>%;" aria-valuenow="<?php echo $data; ?>" aria-valuemin="0" aria-valuemax="100">
                          </div>
                        </div>
                        <?php
        } ?>

                        <?php
    endwhile;
else:
    _e('No post found');
endif;
?>
