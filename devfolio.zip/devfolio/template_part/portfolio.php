<section id="work" class="portfolio-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
              <?php echo get_theme_mod('rahmat_portfolio_title'); ?>
              </h3>
              <p class="subtitle-a">
              <?php echo get_theme_mod('rahmat_portfolio_sub_title'); ?>
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">

        <?php
          $wpportfolio=array('post_type' => 'portfolio',
                        'posts_per_page' => 6,
                        'post_status' => 'publish',
                        'order' =>'ASC'
          );
          $portfolioquery = new WP_Query($wpportfolio);
          if($portfolioquery->have_posts()) : 

          ?>
            <?php while($portfolioquery->have_posts()) : $portfolioquery->the_post(); ?>
            <div class="col-md-4">
                      <div class="work-box">
                        <a href="<?php the_permalink(); ?>" data-gallery="portfolioGallery" class="portfolio-lightbox">
                          <div class="work-img">
                          <?php echo the_post_thumbnail( 'full', array('class' =>'img-fluid')); ?>
                          </div>
                        </a>
                        <div class="work-content">
                          <div class="row">
                            <div class="col-sm-8">
                              <h2 class="w-title"><?php the_title(); ?></h2>
                              <div class="w-more">
                                <span class="w-ctegory">
                                <?php the_category( ',' ); ?>
                                </span> / <span class="w-date"><?php echo get_the_date('d M, Y') ; ?></span>
                              </div>
                            </div>
                            <div class="col-sm-4">
                              <div class="w-like">
                                <a href="<?php the_permalink(); ?>"> <span class="bi bi-plus-circle"></span></a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
            <?php endwhile;
              else :
              _e('No post found');
            endif; 
            ?>

        </div>
      </div>
    </section>