<section id="services" class="services-mf pt-5 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
              <?php echo get_theme_mod('rahmat_service_title'); ?>
              </h3>
              <p class="subtitle-a">
              <?php echo get_theme_mod('rahmat_service_sub_title'); ?>
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">
        <?php
          $wpservice=array('post_type'      => 'service',
                          'posts_per_page' => 6,
                          'post_status'    => 'publish',
                          'order'          => 'ASC'
          );
          $servicequery = new WP_Query($wpservice);
          if($servicequery->have_posts()) : 

          ?>
            <?php 
            global $post;
            while($servicequery->have_posts()) : $servicequery->the_post(); ?>


            <div class="col-md-4">
                      <div class="service-box">
                        <div class="service-ico">
                          <span class="ico-circle"><i class="<?php echo get_post_meta( $post->ID, 'service-icon', true ); ?>"></i></span>
                        </div>
                        <div class="service-content">
                          <h2 class="s-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                          <p class="s-description text-center">
                          <?php the_excerpt(); ?>             
                          </p>
                        </div>
                      </div>
                    </div>

                    <?php endwhile;
              else :
              _e('No post found');
            endif; 
            ?>
        </div>
      </div>
    </section>