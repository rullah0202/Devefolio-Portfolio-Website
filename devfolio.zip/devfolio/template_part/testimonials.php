<div class="testimonials paralax-mf bg-image" style="background-image: url(<?php echo get_theme_mod('rahmat_testimonial_bg_image'); ?>)">
      <div class="overlay-mf"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-12">

            <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
              <div class="swiper-wrapper">
              <?php
                  $wptestimonial=array(
                    'post_type' => 'testimonial',
                    'posts_per_page' => 3,
                    'post_status' => 'publish',
                    'order'   => 'ASC'
                  );
                  $testimonialquery = new WP_Query($wptestimonial);
                  if($testimonialquery->have_posts()) : 

                  ?>
                  <?php while($testimonialquery->have_posts()) : $testimonialquery->the_post(); ?>
                  <div class="swiper-slide">
                    <div class="testimonial-box">
                      <div class="author-test">
                      <div class="author-test">
                                <?php echo the_post_thumbnail( 'full', array('class' =>'rounded-circle b-shadow-a')); ?>
                                <span class="author"><?php the_title(); ?></span>
                              </div>
                      </div>
                      <div class="content-test">
                        <p class="description lead">
                        <?php the_excerpt(); ?>
                        </p>
                      </div>
                    </div>
                  </div><!-- End testimonial item -->
                  <?php endwhile;
                  else :
                  _e('No testimonial found');
                endif; 
                ?>
              </div>
              <div class="swiper-pagination"></div>
            </div>

            <!-- <div id="testimonial-mf" class="owl-carousel owl-theme">
          
        </div> -->
          </div>
        </div>
      </div>
    </div>