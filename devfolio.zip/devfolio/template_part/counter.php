<div class="section-counter paralax-mf bg-image" style="background-image: url(<?php echo get_theme_mod('rahmat_counter_bg_image'); ?>)">
      <div class="overlay-mf"></div>
      <div class="container position-relative">
        <div class="row">
        <?php
          $wpcounter=array('post_type'      => 'counter',
                          'posts_per_page' => 4,
                          'post_status'    => 'publish',
                          'order'         => 'ASC'
          );
          $counterquery = new WP_Query($wpcounter);
          if($counterquery->have_posts()) : 

          ?>
            <?php 
            global $post;
            while($counterquery->have_posts()) : $counterquery->the_post(); ?>

          <div class="col-sm-3 col-lg-3">
            <div class="counter-box pt-4 pt-md-0">
              <div class="counter-ico">
                <span class="ico-circle"><i class="<?php echo get_post_meta( $post->ID, 'counter_icon', true ); ?>"></i></span>
              </div>
              <div class="counter-num">
                <p data-purecounter-start="0" data-purecounter-end="<?php echo get_post_meta( $post->ID, 'total_count', true ); ?>" data-purecounter-duration="1" class="counter purecounter"></p>
                <span class="counter-text"><?php the_title(); ?></span>
              </div>
            </div>
          </div>
          <?php endwhile;
              else :
              _e('No post found');
            endif; 
          ?>

        </div>
      </div>
    </div>