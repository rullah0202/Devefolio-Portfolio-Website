<?php

function rahmat_css_js_file_calling(){

  // CSS Calling
  wp_enqueue_style( 'rahmat-style', get_stylesheet_uri());
  wp_register_style('bootstrap', get_template_directory_uri().'/assets/vendor/bootstrap/css/bootstrap.min.css',array(),'5.1.3', 'all');
  wp_register_style('bootstrap-icon', get_template_directory_uri().'/assets/vendor/bootstrap-icons/bootstrap-icons.css',array(),'5.1.3', 'all');
  wp_register_style('glightbox', get_template_directory_uri().'/assets/vendor/glightbox/css/glightbox.min.css',array(),'5.1.3', 'all');
  wp_register_style('swiper', get_template_directory_uri().'/assets/vendor/swiper/swiper-bundle.min.css',array(),'5.1.3', 'all');
  wp_register_style('style', get_template_directory_uri().'/assets/css/style.css',array(),filemtime(get_template_directory().'/assets/css/style.css'), 'all');
  wp_enqueue_style('bootstrap');
  wp_enqueue_style('bootstrap-icon');
  wp_enqueue_style('glightbox');
  wp_enqueue_style('swiper');
  wp_enqueue_style('style');
  wp_enqueue_style( 'consult-comment-style', get_stylesheet_uri() );
  if ( is_singular() ) wp_enqueue_script( 'comment-reply' );

  // JS Calling
  wp_enqueue_script('jquery');
  wp_register_script( 'bootstrap', get_template_directory_uri().'/assets/vendor/bootstrap/js/bootstrap.bundle.min.js', array(), '5.1.3','true' );
  wp_register_script( 'purecounter', get_template_directory_uri().'/assets/vendor/purecounter/purecounter.js', array(), '5.1.3','true' );
  wp_register_script( 'glightbox', get_template_directory_uri().'/assets/vendor/glightbox/js/glightbox.min.js', array(), '5.1.3','true' );
  wp_register_script( 'swiper', get_template_directory_uri().'/assets/vendor/swiper/swiper-bundle.min.js', array(), '5.1.3','true' );
  wp_register_script( 'typed', get_template_directory_uri().'/assets/vendor/typed.js/typed.min.js', array(), '5.1.3','true' );
  wp_register_script( 'php-email-form', get_template_directory_uri().'/assets/vendor/php-email-form/validate.js', array(), '5.1.3','true' );
  wp_register_script( 'main', get_template_directory_uri().'/assets/js/main.js', array(), filemtime(get_template_directory().'/assets/js/main.js'),'true' );
  wp_enqueue_script('bootstrap');
  wp_enqueue_script('purecounter');
  wp_enqueue_script('glightbox');
  wp_enqueue_script('swiper');
  wp_enqueue_script('typed');
  wp_enqueue_script('php-email-form');
  wp_enqueue_script('main');
}
add_action('wp_enqueue_scripts','rahmat_css_js_file_calling');
