<?php

function devfolio_theme_support(){

    // Theme Title
    add_theme_support('title-tag');
    // Custom Background
    add_theme_support('custom-background');
    // Custom Header
    add_theme_support('custom-header');
    // Thumbnail Image Area
    add_theme_support( 'post-thumbnails', array('page','post','about','portfolio','testimonial'));


}

add_action( 'after_setup_theme','devfolio_theme_support');