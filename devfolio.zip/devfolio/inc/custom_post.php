<?php


// Custom Post for About
function custom_about(){
  register_post_type( 'about', array(
    'labels' => array(
      'name' => __('About', 'rahmat'),
      'singular_name' => __('about', 'rahmat'),
      'menu_name' => __('About', 'rahmat'),
      'name_admin_bar' => __('About', 'rahmat'),
      'add_new' => __('Add New', 'rahmat'),
      'add_new_item' => __('Add New About','rahmat'),
      'new_item' => __('New About','rahmat'),
      'edit_item' => __('Edit About','rahmat'),
      'view_item' => __('View About','rahmat'),
      'all_items' => __('All About','rahmat'),
      'search_items' => __('Search About','rahmat'),
      'not_found' => __('No About found.','rahmat'),
      'featured_image'      => 'About Image',
      'set_featured_image'  => 'Set About Image',
      'remove_featured_image'  => 'Remove About Image',
    ),
    'menu_icon' => 'dashicons-info',
    'description' => 'Holds our About and specific data',
    'public'  => true,
    'taxonomies' => array( 'category', 'post_tag' ),
    'publicly_querable' => true,
    'exclude_from_search' => true,
    'menu_position' => 6,
    'has_archive' => true,
    'hierarchial' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_in_admin_bar' => true,
    'can_export' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'rewrite' => array('slug' => 'about'),
    'supports' => array('title','thumbnail','editor','excerpt','author','custom-fields','comments','revisions','post-formats'),
  ));
}
add_action('init','custom_about');

// Custom Post for Skill
function custom_skill(){
  register_post_type( 'skill', array(
    'labels' => array(
      'name' => __('Skill', 'rahmat'),
      'singular_name' => __('skill', 'rahmat'),
      'menu_name' => __('Skill', 'rahmat'),
      'name_admin_bar' => __('Skill', 'rahmat'),
      'add_new' => __('Add New', 'rahmat'),
      'add_new_item' => __('Add New Skill','rahmat'),
      'new_item' => __('New Skill','rahmat'),
      'edit_item' => __('Edit Skill','rahmat'),
      'view_item' => __('View Skill','rahmat'),
      'all_items' => __('All Skill','rahmat'),
      'search_items' => __('Search Skill','rahmat'),
      'not_found' => __('No Skill found.','rahmat'),
    ),
    'menu_icon' => 'dashicons-welcome-learn-more',
    'description' => 'Holds our Skill and specific data',
    'public'  => true,
    'taxonomies' => array( 'category', 'post_tag' ),
    'publicly_querable' => true,
    'exclude_from_search' => true,
    'menu_position' => 6,
    'has_archive' => true,
    'hierarchial' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_in_admin_bar' => true,
    'can_export' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'rewrite' => array('slug' => 'skill'),
    'supports' => array('title','custom-fields'),
  ));
}
add_action('init','custom_skill');

// Custom Post for Services
function custom_service(){
  register_post_type( 'service', array(
    'labels' => array(
      'name' => __('Services', 'rahmat'),
      'singular_name' => __('services', 'rahmat'),
      'menu_name' => __('Services', 'rahmat'),
      'name_admin_bar' => __('Services', 'rahmat'),
      'add_new' => __('Add New', 'rahmat'),
      'add_new_item' => __('Add New Service','rahmat'),
      'new_item' => __('New Service','rahmat'),
      'edit_item' => __('Edit Service','rahmat'),
      'view_item' => __('View Service','rahmat'),
      'all_items' => __('All Services','rahmat'),
      'search_items' => __('Search Services','rahmat'),
      'not_found' => __('No Service found.','rahmat'),
    ),
    'menu_icon' => 'dashicons-networking',
    'description' => 'Holds our Services and specific data',
    'public'  => true,
    'taxonomies' => array( 'category', 'post_tag' ),
    'publicly_querable' => true,
    'exclude_from_search' => true,
    'menu_position' => 6,
    'has_archive' => true,
    'hierarchial' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_in_admin_bar' => true,
    'can_export' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'rewrite' => array('slug' => 'service'),
    'supports' => array('title','thumbnail','editor','excerpt','author','custom-fields','comments','revisions','post-formats'),
  ));
}
add_action('init','custom_service');

// Custom Post for Counter Area
function custom_counter(){
  register_post_type( 'counter', array(
    'labels' => array(
      'name' => __('Counters', 'rahmat'),
      'singular_name' => __('counters', 'rahmat'),
      'menu_name' => __('Counters', 'rahmat'),
      'name_admin_bar' => __('Counters', 'rahmat'),
      'add_new' => __('Add New', 'rahmat'),
      'add_new_item' => __('Add New Counter','rahmat'),
      'new_item' => __('New Counter','rahmat'),
      'edit_item' => __('Edit Counter','rahmat'),
      'view_item' => __('View Counter','rahmat'),
      'all_items' => __('All Counters','rahmat'),
      'search_items' => __('Search Counters','rahmat'),
      'not_found' => __('No Counters found.','rahmat'),
    ),
    'menu_icon' => 'dashicons-performance',
    'description' => 'Holds our Counters and specific data',
    'public'  => true,
    'taxonomies' => array( 'category', 'post_tag' ),
    'publicly_querable' => true,
    'exclude_from_search' => true,
    'menu_position' => 9,
    'has_archive' => true,
    'hierarchial' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_in_admin_bar' => true,
    'can_export' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'rewrite' => array('slug' => 'counter'),
    'supports' => array('title','custom-fields'),
  ));
}
add_action('init','custom_counter');

// Custom Post for Portfolio
function custom_portfolio(){
  register_post_type( 'portfolio', array(
    'labels' => array(
      'name' => __('Portfolios', 'rahmat'),
      'singular_name' => __('portfolios', 'rahmat'),
      'menu_name' => __('Portfolios', 'rahmat'),
      'name_admin_bar' => __('Portfolios', 'rahmat'),
      'add_new' => __('Add New', 'rahmat'),
      'add_new_item' => __('Add New Portfolio','rahmat'),
      'new_item' => __('New Portfolio','rahmat'),
      'edit_item' => __('Edit Portfolio','rahmat'),
      'view_item' => __('View Portfolio','rahmat'),
      'all_items' => __('All Portfolios','rahmat'),
      'search_items' => __('Search Portfolios','rahmat'),
      'not_found' => __('No Portfolios found.','rahmat'),
      'featured_image'      => 'Portfolio Image',
      'set_featured_image'  => 'Set Portfolio Image',
      'remove_featured_image'  => 'Remove Portfolio Image',
    ),
    'menu_icon' => 'dashicons-portfolio',
    'description' => 'Holds our Portfolios and specific data',
    'public'  => true,
    'taxonomies' => array( 'category', 'post_tag' ),
    'publicly_querable' => true,
    'exclude_from_search' => true,
    'menu_position' => 7,
    'has_archive' => true,
    'hierarchial' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_in_admin_bar' => true,
    'can_export' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'rewrite' => array('slug' => 'portfolio'),
    'supports' => array('title','thumbnail','editor','excerpt','author','custom-fields','comments','revisions','post-formats'),
  ));
}
add_action('init','custom_portfolio');

// Custom Post for Testimonial
function custom_testimonial(){
  register_post_type( 'testimonial', array(
    'labels' => array(
      'name' => __('Testimonials', 'rahmat'),
      'singular_name' => __('testimonials', 'rahmat'),
      'menu_name' => __('Testimonials', 'rahmat'),
      'name_admin_bar' => __('Testimonials', 'rahmat'),
      'add_new' => __('Add New', 'rahmat'),
      'add_new_item' => __('Add New Testimonial','rahmat'),
      'new_item' => __('New Testimonial','rahmat'),
      'edit_item' => __('Edit Testimonial','rahmat'),
      'view_item' => __('View Testimonial','rahmat'),
      'all_items' => __('All Testimonials','rahmat'),
      'search_items' => __('Search Testimonials','rahmat'),
      'not_found' => __('No Testimonials found.','rahmat'),
      'featured_image'      => 'Testimonial Image',
      'set_featured_image'  => 'Set Testimonial Image',
      'remove_featured_image'  => 'Remove Testimonial Image',
    ),
    'menu_icon' => 'dashicons-testimonial',
    'description' => 'Holds our Testimonials and specific data',
    'public'  => true,
    'taxonomies' => array( 'category', 'post_tag' ),
    'publicly_querable' => true,
    'exclude_from_search' => true,
    'menu_position' => 8,
    'has_archive' => true,
    'hierarchial' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_in_admin_bar' => true,
    'can_export' => true,
    'query_var' => true,
    'capability_type' => 'post',
    'rewrite' => array('slug' => 'testimonial'),
    'supports' => array('title','thumbnail','editor','excerpt','author','custom-fields','comments','revisions','post-formats'),
  ));
}
add_action('init','custom_testimonial');