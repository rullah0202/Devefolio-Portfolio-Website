<?php

register_nav_menu( 'main_menu',__('Main Menu','rahmat' ));

// Walker Menu Properties
function rahmat_nav_description($item_output,$item,$args){
    if(!empty($item -> description)){
      $item_output = str_replace('</a>','<i class="'. $item->description . '"></i>' . '</a>' , $item_output );
    }
    return $item_output;
  }
  add_filter('walker_nav_menu_start_el','rahmat_nav_description',10,3);

  function add_menuclass($ulclass) {
    return preg_replace('/<a /', '<a class="nav-link scrollto"', $ulclass);
 }
 add_filter('wp_nav_menu','add_menuclass');
  // Custom Nav Menu
//   function clean_custom_menu( $theme_location ) {
//     if ( ($theme_location) && ($locations = get_nav_menu_locations()) && isset($locations[$theme_location]) ) {
//         $menu = get_term( $locations[$theme_location], 'nav_menu' );
//         $menu_items = wp_get_nav_menu_items($menu->term_id);
 
//         $menu_list  = '<nav id="navbar" class="navbar">' ."\n";
//         $menu_list .= '<ul>' ."\n";
 
//         // $count = 0;
//         // $submenu = false;
//         $bool=false;
         
//         foreach( $menu_items as $menu_item ) {
            
//             if( $menu_item->menu_item_parent == 0 ) {
                 
//                 $parent = $menu_item->ID;
                 
//                 $menu_array = array();
//                 foreach( $menu_items as $submenu ) {
//                     if( $submenu->menu_item_parent == $parent ) {
//                         $bool = true;
//                         $menu_array[] = '<li><a href="' . $submenu->url . '">' . $submenu->title . '</a></li>' ."\n";
//                     }
//                 }
//                 if( $bool == true && count( $menu_array ) > 0 ) {
                     
//                     $menu_list .= '<li class="dropdown">' ."\n";
//                     $menu_list .= '<a href="' . $menu_item->url . '"><span>'. $menu_item->title . '</span><i class="bi bi-chevron-down"></i></a>' ."\n";
                     
//                     $menu_list .= '<ul>' ."\n";
//                     $menu_list .= implode( "\n", $menu_array );
//                     $menu_list .= '</ul>' ."\n";
                    
//                 } else {
                     
//                     $menu_list .= '<li>' ."\n";
//                     $menu_list .= '<a class="nav-link scrollto" href="' . $menu_item->url . '">' . $menu_item->title . '</a>' ."\n";
//                 }
                 
//             }
             
//             // end <li>
//             $menu_list .= '</li>' ."\n";
//         }
         
//         $menu_list .= '</ul>' ."\n";
//         $menu_list .= '<i class="bi bi-list mobile-nav-toggle"></i></nav>' ."\n";
 
//     } else {
//         $menu_list = '<!-- no menu defined in location "'.$theme_location.'" -->';
//     }
//     echo $menu_list;
// }