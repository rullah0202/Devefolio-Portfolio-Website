<?php

function rahmat_customizer_register($wp_customize){

    //Header Area Function
    //Logo
    $wp_customize->add_section('rahmat_header_area',array(
      'title' =>__('Header Area','rahmat'),
      'description' => 'If you interested to update your header area, you can do it here'
    ));
  
    $wp_customize->add_setting('rahmat_logo',array(
      'default' => 'DevFolio',
      'transport' => 'refresh'
    ));
  
    $wp_customize->add_control('rahmat_logo',array(
      'label'=> 'Add Logo Text',
      'setting'=> 'rahmat_logo',
      'section'=> 'rahmat_header_area',
      'description' => 'If you interested to change your  Logo Text, you can do it here'
    ));

    // Hero Part

        // Hero Text Main
        $wp_customize->add_setting('header_text_main',array(
            'default' => 'I am Morgan Freeman',
            'transport' => 'refresh'
          ));
        
          $wp_customize->add_control('header_text_main',array(
            'label'=> 'Add Header Main Text',
            'setting'=> 'header_text_main',
            'section'=> 'header_image',
            'type'   => 'text',
          ));
  
          // Hero Text Sub
          $wp_customize->add_setting('header_text_sub',array(
            'default' => 'Designer, Developer, Freelancer, Photographer',
            'transport' => 'refresh'
          ));
        
          $wp_customize->add_control('header_text_sub',array(
            'label'=> 'Add Header Sub Text',
            'setting'=> 'header_text_sub',
            'section'=> 'header_image',
            'type'   => 'text',
          ));


  // Service Title and Sub Title
$wp_customize->add_section('rahmat_service_area',array(
  'title'=>__('Service Area','rahmat'),
  'description'=>'You can update your Service Title and Sub Title here'
));
      // Service Title
      $wp_customize->add_setting('rahmat_service_title',array(
        'default' => 'SERVICES'
        ));
        $wp_customize->add_control('rahmat_service_title',array(
          'label'=> 'Service Title',
          'description' => 'If need you can change your Service title text here',
          'setting' => 'rahmat_service_title',
          'section' => 'rahmat_service_area',
        ));
          // Service Sub Title
        $wp_customize->add_setting('rahmat_service_sub_title',array(
        'default' => 'Lorem ipsum, dolor sit amet consectetur adipisicing elit.'
        ));
        $wp_customize->add_control('rahmat_service_sub_title',array(
          'label'=> 'Service Sub Title',
          'description' => 'If need you can change your Service Sub title text here',
          'setting' => 'rahmat_service_sub_title',
          'section' => 'rahmat_service_area',
        ));
// End Service

// Counter Background Image
      $wp_customize->add_section('rahmat_counter_area',array(
        'title'=>__('Counter Area','rahmat'),
        'description'=>'You can update your Counter Background Image here'
      ));
      // Counter Background Image
      $wp_customize->add_setting('rahmat_counter_bg_image',array(
        'default' => get_bloginfo('template_directory') . '/assets/img/counters-bg.jpg',
      ));
      $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'rahmat_counter_bg_image',array(
        'label'=> 'Background Upload or Change',
        'description'=>'You can update or change your Counter background image here',
        'setting' => 'rahmat_counter_bg_image',
        'section' => 'rahmat_counter_area',
      )));

// Portfolio Background Image, Title and Sub Title
$wp_customize->add_section('rahmat_portfolio_area',array(
  'title'=>__('Portfolio Area','rahmat'),
  'description'=>'You can update your Portfolio Details here'
));

      // Portfolio Title
      $wp_customize->add_setting('rahmat_portfolio_title',array(
        'default' => 'PORTFOLIO'
        ));
        $wp_customize->add_control('rahmat_portfolio_title',array(
          'label'=> 'Portfolio Title',
          'description' => 'If need you can change your Portfolio title text here',
          'setting' => 'rahmat_portfolio_title',
          'section' => 'rahmat_portfolio_area',
        ));
          // Portfolio Sub Title
        $wp_customize->add_setting('rahmat_portfolio_sub_title',array(
        'default' => 'Lorem ipsum, dolor sit amet consectetur adipisicing elit.'
        ));
        $wp_customize->add_control('rahmat_portfolio_sub_title',array(
          'label'=> 'Portfolio Sub Title',
          'description' => 'If need you can change your Portfolio Sub title text here',
          'setting' => 'rahmat_portfolio_sub_title',
          'section' => 'rahmat_portfolio_area',
        ));
// End Portfolio

// Testimonial Background Image
$wp_customize->add_section('rahmat_testimonial_area',array(
  'title'=>__('Testimonial Area','rahmat'),
  'description'=>'You can update your Testimonial Background Image here'
));
      // Testimonial Background Image
      $wp_customize->add_setting('rahmat_testimonial_bg_image',array(
        'default' => get_bloginfo('template_directory') . '/assets/img/overlay-bg.jpg',
      ));
      $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize,'rahmat_testimonial_bg_image',array(
        'label'=> 'Background Upload or Change',
        'description'=>'You can update or change your testimonial background image here',
        'setting' => 'rahmat_testimonial_bg_image',
        'section' => 'rahmat_testimonial_area',
      )));


}

add_action('customize_register','rahmat_customizer_register');